package com.weather.melbourneweatherreport.service;

import static org.assertj.core.api.Assertions.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.weather.melbourneweatherreport.Exception.MelbourneweatherReportException;
import com.weather.melbourneweatherreport.model.MelbourneweatherReport;
import com.weather.melbourneweatherreport.serviceImpl.MelbourneweatherServiceImpl;
import com.weather.melbourneweatherreport.serviceImpl.OpenWeatherMapServiceImpl;
import com.weather.melbourneweatherreport.serviceImpl.WeatherStackServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class MelbourneweatherServiceTest {

	@InjectMocks
	private MelbourneweatherServiceImpl melbourneweatherService;

	@Mock
	private OpenWeatherMapServiceImpl mapServiceImpl;

	@Mock
	private WeatherStackServiceImpl stackServiceImpl;

	private MelbourneweatherReport melbourneweatherReport;

	@Before
	public void setUp() {
		melbourneweatherReport = new MelbourneweatherReport(12, 13);
	}

	@Test
	public void testGetMelbourneweatherReportForWeatherStack() throws Exception {
		Mockito.when(stackServiceImpl.getWeatherDetails("melbourne")).thenReturn(melbourneweatherReport);

		MelbourneweatherReport result = melbourneweatherService.getMelbourneweatherReport("melbourne");

		assertNotNull(result);
		assertEquals(12, result.getTemperature_degrees());
		assertEquals(13, result.getWind_speed());

		Mockito.verify(mapServiceImpl, Mockito.never()).getWeatherDetails(Mockito.anyString());
	}

	@Test
	public void testGetMelbourneweatherReportForOpenWeather() throws Exception {
		Mockito.when(stackServiceImpl.getWeatherDetails("melbourne")).thenThrow(new RuntimeException("Primary provider failed"));
		Mockito.when(mapServiceImpl.getWeatherDetails("melbourne")).thenReturn(melbourneweatherReport);

		MelbourneweatherReport result = melbourneweatherService.getMelbourneweatherReport("melbourne");

		assertNotNull(result);
		assertEquals(12, result.getTemperature_degrees());
		assertEquals(13, result.getWind_speed());
		
		Mockito.verify(stackServiceImpl).getWeatherDetails("melbourne");
	    Mockito.verify(mapServiceImpl).getWeatherDetails("melbourne");

	}
	
	@Test(expected = MelbourneweatherReportException.class)
	public void testGetMelbourneweatherReport() throws Exception {
		Mockito.when(stackServiceImpl.getWeatherDetails("melbourne")).thenThrow(new RuntimeException("Primary provider failed"));
		Mockito.when(mapServiceImpl.getWeatherDetails("melbourne")).thenThrow(new RuntimeException("Secondry provider failed"));

		MelbourneweatherReport result = melbourneweatherService.getMelbourneweatherReport("melbourne");

		 try {
	            melbourneweatherService.getMelbourneweatherReport("melbourne");
	            fail("Expected MelbourneweatherReportException to be thrown");
	        } catch (MelbourneweatherReportException ex) {
	            assertEquals("Weather details for this City not Found", ex.getMessage());
	        }
		
		Mockito.verify(stackServiceImpl).getWeatherDetails("melbourne");
	    Mockito.verify(mapServiceImpl).getWeatherDetails("melbourne");

	}

}