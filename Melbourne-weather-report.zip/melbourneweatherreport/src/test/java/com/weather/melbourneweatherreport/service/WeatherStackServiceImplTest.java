package com.weather.melbourneweatherreport.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.weather.melbourneweatherreport.model.MelbourneweatherReport;
import com.weather.melbourneweatherreport.serviceImpl.WeatherStackServiceImpl;

@ExtendWith(MockitoExtension.class)
public class WeatherStackServiceImplTest {
	@Mock
	private RestTemplate restTemplate;

	@Mock
	private MelbourneweatherReport melbourneweatherReport;

	@InjectMocks
	private WeatherStackServiceImpl serviceImpl;

	private Map<String, Object> currentMap;

    @BeforeEach
    public void setup() {
        currentMap = new HashMap<>();
        currentMap.put("temperature", 29);
        currentMap.put("wind_speed", 20);
    }
    
	@Test
	public void testGetWeatherDetails() throws Exception {
		Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("current", currentMap);

        ResponseEntity<Map> responseEntity = ResponseEntity.ok(responseMap);

        Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(Map.class)))
               .thenReturn(responseEntity);

        MelbourneweatherReport result = serviceImpl.getWeatherDetails("melbourne");

        assertEquals(29, result.getTemperature_degrees());
        assertEquals(20, result.getWind_speed());
    }

	@Test
    public void testGetWeatherDetails_nullCurrent() throws Exception {
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("current", null);

        ResponseEntity<Map> responseEntity = ResponseEntity.ok(responseMap);

        Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(Map.class)))
               .thenReturn(responseEntity);

        MelbourneweatherReport result = serviceImpl.getWeatherDetails("melbourne");

        assertNull(result);
    }
}
