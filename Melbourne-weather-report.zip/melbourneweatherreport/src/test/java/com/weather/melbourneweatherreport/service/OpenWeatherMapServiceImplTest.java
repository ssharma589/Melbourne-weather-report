package com.weather.melbourneweatherreport.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.weather.melbourneweatherreport.model.MelbourneweatherReport;
import com.weather.melbourneweatherreport.serviceImpl.OpenWeatherMapServiceImpl;

@ExtendWith(MockitoExtension.class)
public class OpenWeatherMapServiceImplTest {

	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	private OpenWeatherMapServiceImpl mapServiceImpl;

	private Map<String, Object> mockMain;
	private Map<String, Object> mockWind;
	private Map<String, Object> responseBody;

	@BeforeEach
	public void setUp() {
		mockMain = new HashMap<>();
		mockMain.put("temp", 25.6);

		mockWind = new HashMap<>();
		mockWind.put("speed", 12.3);

		responseBody = new HashMap<>();
		responseBody.put("main", mockMain);
		responseBody.put("wind", mockWind);
	}

	@Test
	public void testGetWeatherDetails_returnsValidReport() throws Exception {
		ResponseEntity<Map> responseEntity = ResponseEntity.ok(responseBody);

		Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(Map.class))).thenReturn(responseEntity);

		MelbourneweatherReport report = mapServiceImpl.getWeatherDetails("melbourne");

		assertEquals(25, report.getTemperature_degrees()); // intValue() truncates to 25
		assertEquals(12, report.getWind_speed()); // intValue() truncates to 12
	}

	@Test
	public void testGetWeatherDetails_returnsNull() throws Exception {
		Map<String, Object> emptyBody = new HashMap<>();
		ResponseEntity<Map> responseEntity = ResponseEntity.ok(emptyBody);

		Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.eq(Map.class))).thenReturn(responseEntity);

		MelbourneweatherReport report = mapServiceImpl.getWeatherDetails("melbourne");

		assertNull(report);
	}

}
