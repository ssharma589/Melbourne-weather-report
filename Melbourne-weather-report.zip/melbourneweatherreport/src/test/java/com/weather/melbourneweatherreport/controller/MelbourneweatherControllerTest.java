package com.weather.melbourneweatherreport.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.assertj.MockMvcTester.MockMvcRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.weather.melbourneweatherreport.model.MelbourneweatherReport;
import com.weather.melbourneweatherreport.service.MelbourneweatherService;

@WebMvcTest(MelbourneweatherController.class)
public class MelbourneweatherControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private MelbourneweatherService melbourneweatherService;

	@Test
	public void testGetWeatherInfo() throws Exception {
		MelbourneweatherReport mockReport = new MelbourneweatherReport(29, 20);
		when(melbourneweatherService.getMelbourneweatherReport("melbourne")).thenReturn(mockReport);

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/weather")).andExpect(status().isOk())
				.andExpect(jsonPath("$.temperature_degrees").value(29)).andExpect(jsonPath("$.wind_speed").value(20));
	}

	@Test
	public void testGetWeatherInfo_CustomCity_Success() throws Exception {
		MelbourneweatherReport mockReport = new MelbourneweatherReport(25, 10);
		when(melbourneweatherService.getMelbourneweatherReport("delhi")).thenReturn(mockReport);

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/weather?city=delhi")).andExpect(status().isOk())
				.andExpect(jsonPath("$.temperature_degrees").value(25)).andExpect(jsonPath("$.wind_speed").value(10));
	}

}
