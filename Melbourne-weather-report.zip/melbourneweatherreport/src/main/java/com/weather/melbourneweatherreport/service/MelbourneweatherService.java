package com.weather.melbourneweatherreport.service;

import com.weather.melbourneweatherreport.Exception.MelbourneweatherReportException;
import com.weather.melbourneweatherreport.model.MelbourneweatherReport;

public interface MelbourneweatherService {
	MelbourneweatherReport getMelbourneweatherReport(String city) throws MelbourneweatherReportException;
}
