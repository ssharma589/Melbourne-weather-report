package com.weather.melbourneweatherreport.service;

import com.weather.melbourneweatherreport.model.MelbourneweatherReport;

public interface MelbourneweatherProvider {
		MelbourneweatherReport	getWeatherDetails(String city) throws Exception;
}
