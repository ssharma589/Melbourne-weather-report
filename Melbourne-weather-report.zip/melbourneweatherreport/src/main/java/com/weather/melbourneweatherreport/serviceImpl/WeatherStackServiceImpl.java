package com.weather.melbourneweatherreport.serviceImpl;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.weather.melbourneweatherreport.model.MelbourneweatherReport;
import com.weather.melbourneweatherreport.service.MelbourneweatherProvider;

@Component
public class WeatherStackServiceImpl implements MelbourneweatherProvider {

	private String key = "c47ec18c581c5a1509d3954f9c1af536";

	private RestTemplate restTemplate = new RestTemplate();

	@Override
	public MelbourneweatherReport getWeatherDetails(String city) throws Exception {
		MelbourneweatherReport weather = null;
		String url = String.format("http://api.weatherstack.com/current?access_key=c47ec18c581c5a1509d3954f9c1af536&query=Melbourne");
		ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
		Map current = (Map) response.getBody().get("current");
		if (current != null) {
			weather = new MelbourneweatherReport((int) current.get("temperature"), (int) current.get("wind_speed"));
		}

		return weather;

	}

}
