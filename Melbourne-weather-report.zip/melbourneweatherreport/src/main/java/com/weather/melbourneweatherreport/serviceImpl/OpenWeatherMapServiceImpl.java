package com.weather.melbourneweatherreport.serviceImpl;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.weather.melbourneweatherreport.model.MelbourneweatherReport;
import com.weather.melbourneweatherreport.service.MelbourneweatherProvider;

import lombok.Value;

@Component
public class OpenWeatherMapServiceImpl implements MelbourneweatherProvider {

	
	private String key = "c47ec18c581c5a1509d3954f9c1af536";
	
	private RestTemplate restTemplate = new RestTemplate();

	@Override
	public MelbourneweatherReport getWeatherDetails(String city) throws Exception {
		MelbourneweatherReport weather = null;
		String url = String.format("http://api.openweathermap.org/data/2.5/weather?q=melbourne,AU&appid=2326504fb9b100bee21400190e4dbe6d");
		ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
		Map main = (Map) response.getBody().get("main");
		Map wind = (Map) response.getBody().get("wind");
	 
		if (main != null || wind != null) {
			weather = new MelbourneweatherReport(((Double) main.get("temp")).intValue(),
					((Double) wind.get("speed")).intValue());
		}

		return weather;

	}

}
