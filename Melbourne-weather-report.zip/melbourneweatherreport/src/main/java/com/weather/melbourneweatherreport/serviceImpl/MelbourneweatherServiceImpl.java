package com.weather.melbourneweatherreport.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.weather.melbourneweatherreport.Exception.MelbourneweatherReportException;
import com.weather.melbourneweatherreport.model.MelbourneweatherReport;
import com.weather.melbourneweatherreport.service.MelbourneweatherService;

@Component
public class MelbourneweatherServiceImpl implements MelbourneweatherService {

	@Autowired
	private OpenWeatherMapServiceImpl mapServiceImpl;
	
	@Autowired
	private WeatherStackServiceImpl stackServiceImpl;
	
	private MelbourneweatherReport weReport ;
	
	@Cacheable(value="weather", key="#city")
	@Override
	public MelbourneweatherReport getMelbourneweatherReport(String city) throws MelbourneweatherReportException {
		try {
			 weReport =	stackServiceImpl.getWeatherDetails("melbourne");
		} catch (Exception e) {
			try {
				weReport = mapServiceImpl.getWeatherDetails("melbourne");
			} catch (Exception e2) {
				throw new MelbourneweatherReportException("Weather details for this City not Found");
			}
		}
		return weReport;
	}

}
