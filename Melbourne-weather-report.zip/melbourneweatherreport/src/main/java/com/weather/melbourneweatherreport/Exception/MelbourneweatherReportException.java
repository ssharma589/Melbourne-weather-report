package com.weather.melbourneweatherreport.Exception;

public class MelbourneweatherReportException extends Exception {
	public MelbourneweatherReportException(String msg) {
		super();
	}
}
