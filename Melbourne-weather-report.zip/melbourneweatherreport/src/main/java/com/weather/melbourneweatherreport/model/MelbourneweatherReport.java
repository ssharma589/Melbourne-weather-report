package com.weather.melbourneweatherreport.model;

public class MelbourneweatherReport {

	private int temperature_degrees;
	private int wind_speed;

	public MelbourneweatherReport(int temperature_degrees, int wind_speed) {
		super();
		this.temperature_degrees = temperature_degrees;
		this.wind_speed = wind_speed;
	}

	public int getTemperature_degrees() {
		return temperature_degrees;
	}

	public void setTemperature_degrees(int temperature_degrees) {
		this.temperature_degrees = temperature_degrees;
	}

	public int getWind_speed() {
		return wind_speed;
	}

	public void setWind_speed(int wind_speed) {
		this.wind_speed = wind_speed;
	}

}
