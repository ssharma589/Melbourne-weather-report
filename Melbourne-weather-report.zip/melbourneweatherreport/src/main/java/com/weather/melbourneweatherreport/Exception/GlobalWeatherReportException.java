package com.weather.melbourneweatherreport.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalWeatherReportException {

	@ExceptionHandler(value = MelbourneweatherReportException.class)
	public ResponseEntity<Object> getException(MelbourneweatherReportException exception) {
		String errorMessage = "Weather details not Found";
		return new ResponseEntity<>(errorMessage, HttpStatus.NOT_FOUND);
	}
}
